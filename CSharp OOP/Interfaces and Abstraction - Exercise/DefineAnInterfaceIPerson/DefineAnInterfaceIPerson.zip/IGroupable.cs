﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    interface IGroupable
    {
        public string Group { get;}
    }
}
