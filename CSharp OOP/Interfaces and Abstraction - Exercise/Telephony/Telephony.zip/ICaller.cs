﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface ICaller
    {
        void Call(string phoneNumber);
    }
}
