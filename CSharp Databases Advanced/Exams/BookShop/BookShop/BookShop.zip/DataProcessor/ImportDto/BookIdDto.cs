﻿namespace BookShop.DataProcessor.ImportDto
{
    public class BookIdDto
    {
        public int? Id { get; set; }
    }
}
