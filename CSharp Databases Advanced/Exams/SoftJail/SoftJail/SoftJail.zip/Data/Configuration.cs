﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=EVTIM\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
